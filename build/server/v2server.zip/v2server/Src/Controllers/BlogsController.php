<?php

namespace Server\Src\Controllers;

class BlogsController {
    
}