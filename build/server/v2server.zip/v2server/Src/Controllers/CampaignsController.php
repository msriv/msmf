<?php

namespace Server\Src\Controllers;

class CampaignsController {
    
}