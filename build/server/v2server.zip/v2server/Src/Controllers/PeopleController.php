<?php

namespace Server\Src\Controllers;

class PeopleController {
    
}