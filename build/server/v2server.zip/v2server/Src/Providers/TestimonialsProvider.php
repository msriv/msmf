<?php

namespace Server\Src\Providers;

class TestimonalsProvider extends Provider  {

}