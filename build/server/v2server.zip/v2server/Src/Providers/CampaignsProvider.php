<?php

namespace Server\Src\Providers;

class CampaignsProvider extends Provider  {

}