<?php

namespace Server\Src\Providers;

class PeopleProvider extends Provider  {

}