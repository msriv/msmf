<?php

namespace Server\Src\Providers;

class BlogsProvider extends Provider  {

}