<?php

namespace Server\Src\Providers;

use Server\Src\Utils\Helpers;

class AuthProvider extends Provider  {

    public function __construct() {}
    public function generateToken($userId) {
        return Helpers::createSuccessResponse(201, array("token" => $userToken));
    }

        public function validate_token($token) {

            if (Token::validate($token, $this->secret) && Token::validateExpiration($token, $this->secret)) {
                $result["ok"] = true;
                $response['status_code_header'] = 'HTTP/1.1 200 OK';
            }
            
            $response['body'] = json_encode($result);
            return $response;
        }
}
