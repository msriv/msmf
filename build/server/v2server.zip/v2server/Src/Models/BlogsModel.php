<?php

namespace Server\Src\Models;

class BlogsModel {
    
}