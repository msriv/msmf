<?php

namespace Server\Src\Models;

class CampaignsModel {
    
}