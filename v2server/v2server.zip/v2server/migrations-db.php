<?php

use Server\Src\Utils\Constants;
require_once("bootstrap.php");

return $connection;
