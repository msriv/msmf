<?php
namespace Src\Controllers;

class AssetsManager {
  private $db;
  private $handler;
  private $vars;

  public function __construct($db, $handler, $vars) {
    $this->db = $db;
    $this->handler = $handler;
    $this->vars = $vars;
  }

  public function processRequest() {
        switch ($this->handler) {
            case 'create_assets':
            $response = $this->createAssets();
        break;
        }
        header($response['status_code_header']);
    if ($response['body']) {
        echo $response['body'];
    }
    }

    private function createAssets() {
        $num_files = count($_FILES['files']['name']);
        $uploaded_files = 0;
        $target_dir = SITE_ROOT . "/uploads/";
        for($i=0; $i < $num_files; $i++) {
            $target_file = $target_dir . basename($_FILES["files"]["name"][$i]);
            $uploadOk = 1;
            $imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
            if(isset($_FILES["files"])) {
                $check = getimagesize($_FILES["files"]["tmp_name"][$i]);
                var_dump($check);
                if($check !== false) {
                    $uploadOk = 1;
                } else {
                    $uploadOk = 0;
                }


            if ($uploadOk == 0) {
                echo "Sorry, your file was not uploaded.";
            } else {
                if (move_uploaded_file($_FILES["files"]["tmp_name"][$i], $target_file)) {
                    $uploaded_files++;
                }

                $query = "
                  INSERT INTO assets
                      (uid, name, alt, width, height, uri, mime)
                  VALUES
                      (:uid, :name, :alt, :width, :height, :uri, :mime);
                ";
                try {
                    $statement = $this->db->prepare($query);
                    $statement->execute(array(
                        'uid' => MD5(basename($_FILES["files"]["name"][$i])),
                        'name' => basename($_FILES["files"]["name"][$i]),
                        'alt' => basename($_FILES["files"]["name"][$i]),
                        'width' => $check[0],
                        'height'  => $check[1],
                        'uri' => $_ENV['BASE_URI'] . "/uploads/" . basename($_FILES["files"]["name"][$i]),
                        'mime' => $check['mime']
                    ));
          $statement->rowCount();
        } catch (\PDOException $e) {
          exit($e->getMessage());
        }
      }} else {
        echo "Sorry, there was an error uploading your file.";
      }
    }
        if($uploaded_files == $num_files) {
            $response['status_code_header'] = 'HTTP/1.1 201 Created';
            $response['body'] = json_encode(array('message' => 'Post Created'));
            return $response;
        }else {
            $response['status_code_header'] = 'HTTP/1.1 500 Internal Server Error';
            $response['body'] = json_encode(array('message' => 'Upload Failed'));
            return $response;
        }
            }
        }    